package cs.view;

import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.Group;
import javafx.scene.layout.AnchorPane;
import cs.MainController;

public class MainViewController {
	
	@FXML
	private Group leftgroup;
	
	@FXML
	private Group rightgroup;
	
	@FXML
	private Label user = new Label("user");
	
	@FXML
	private Label pos = new Label("pos");
	
	private MainController mainc;
	
	public MainViewController(){
		
	}
	
	public void setParam(String uid, String position){
		user.setText(uid);
		pos.setText(position);
	}
	
	public MainController getMain(){
		return mainc;
	}
	
	public void setMain(MainController main){
		this.mainc = main;
	}
	
	public void setLeft(AnchorPane left) {
		leftgroup.getChildren().add(left);
	}
	
	public void setRight(AnchorPane right){
		rightgroup.getChildren().clear();
		rightgroup.getChildren().add(right);
	}
	
}
