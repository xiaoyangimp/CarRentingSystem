package cs.view;

import java.io.IOException;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.Button;
import javafx.scene.layout.AnchorPane;
import cs.view.ReserveViewController;
import cs.MainController;

public class AdminToolbarController extends ToolbarController {
	@FXML
	private Button reserveV;
	
	@FXML
	private Button rentV;
	
	@FXML
	private Button returnV;
	
	@FXML
	private Button report;
	
	private MainController mainc;
	
	public AdminToolbarController(){
		
	}
	
	public MainController getMain(){
		return mainc;
	}
	
	public void setMain(MainController main){
		this.mainc = main;
	}
	
	@FXML
	public void reserve(){
		try {
			FXMLLoader loader = new FXMLLoader();
			loader.setLocation(MainController.class.getResource("view/ReserveView.fxml"));
			AnchorPane reserve = (AnchorPane) loader.load();
		
			ReserveViewController con = loader.getController();
			mainc.getMainViewController().setRight(reserve);
			con.setMainVC(mainc.getMainViewController());
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
}
