package cs.view;

import cs.MainController;

public abstract class ToolbarController {
	public abstract void setMain(MainController main);
}
