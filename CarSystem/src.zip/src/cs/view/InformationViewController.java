package cs.view;


import java.sql.*;

import cs.SQLConnect;
import cs.model.Reservation;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.control.Label;

public class InformationViewController {
	
	@FXML
	private TextField cname;
	
	@FXML
	private TextField cphonenum;
		
	@FXML
	private Label info;
	
	@FXML
	private Button reserve;
	
	private Reservation res = new Reservation();
	
	@FXML
	public void makeReservation(){
		String name = cname.getText();
		String phonenum = cphonenum.getText();
		
		
		if(name.length() == 0 || phonenum.length() == 0) {
			info.setText("Please give an valid name or phonenum");
			return ;
		}
		
		res.setcname(name);
		res.setcphonenum(phonenum);
		
		PreparedStatement ps;
		Statement stmt;
		ResultSet rs;
		
		try{
			ps = SQLConnect.getcon().prepareStatement("INSERT INTO Transaction (startdate, returndate) VALUES (?,?)");
			ps.setTimestamp(1, new java.sql.Timestamp(res.getstartdate().getTime().getTime()));
			ps.setTimestamp(2, new java.sql.Timestamp(res.getreturndate().getTime().getTime()));
			
			ps.executeUpdate();
			SQLConnect.getcon().commit();
			ps.close();
			
			stmt = SQLConnect.getcon().createStatement();
			
			rs = stmt.executeQuery("SELECT tid FROM Transaction where tid = LAST_INSERT_ID()");
			
			if( ! rs.next() ) {
				info.setText("DataBase error!");
			}
			else {
				res.settid(rs.getInt("tid"));
				stmt.close();
				
				int tempconfirm = 0;
				tempconfirm += res.gettid();
				tempconfirm *= 10;
				tempconfirm += res.getbid();
				tempconfirm *= 100000;
				tempconfirm += res.getvid();
				
				res.setconfirmnum(tempconfirm);
				
				ps = SQLConnect.getcon().prepareStatement("INSERT INTO Reservation VALUES (?,?,?,?,?,?)"); 
				
				ps.setInt(1, res.gettid());
				ps.setInt(2, res.getbid());
				ps.setInt(3, res.getvid());
				ps.setString(4, res.getcname());
				ps.setInt(5, res.getconfirmnum());
				ps.setString(6, res.getcphonenum());
				
				ps.executeUpdate();
				SQLConnect.getcon().commit();
				ps.close();
				
				ps = SQLConnect.getcon().prepareStatement("INSERT INTO Contain VALUES (?,?)"); 
				ps.setInt(1, res.gettid());
				ps.setString(2, res.getequip());
				
				ps.executeUpdate();
				SQLConnect.getcon().commit();
				ps.close();
				
				info.setText("Thanks for the reservation, your confirm number is " + res.getconfirmnum() + ".");
				
				cname.setDisable(true);;
				cphonenum.setDisable(true);
				reserve.setDisable(true);
			}
		} catch (SQLException ex) {
			info.setText("Message:" + ex.getMessage());
		}
	}
	
	@FXML
	public void initialize(){
		cname.setDisable(true);
		cphonenum.setDisable(true);
		reserve.setDisable(true);
	}
	
	public void setReservation(Reservation r) {
		this.res = r;
		info.setText("Current selected vehilce is " + res.getvid() + ".");
		
		cname.setDisable(false);
		cphonenum.setDisable(false);
		reserve.setDisable(false);
	}
	
	
}
