package cs.view;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.Label;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Button;
import javafx.scene.control.SelectionMode;
import javafx.scene.control.TableView;
import javafx.scene.control.TableColumn;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.AnchorPane;
import cs.constant.CommonC;
import cs.MainController;
import cs.SQLConnect;
import cs.SQLSearch;
import cs.model.Reservation;
import cs.model.Equipment;
import cs.constant.Translate;

import java.time.LocalDate;
import java.util.Calendar;
import java.io.IOException;
import java.sql.*;

public class ReserveViewController {
	@FXML 
	private ChoiceBox<String> address = new ChoiceBox<String>();
	
	@FXML
	private ChoiceBox<String> type = new ChoiceBox<String>();
	
	@FXML
	private DatePicker pickupdate;
	
	@FXML
	private DatePicker returndate;
	
	@FXML
	private ChoiceBox<Integer> pickuphour;
	
	@FXML
	private ChoiceBox<Integer> returnhour;
	
	@FXML
	private Button check;
	
	@FXML
	private Label DBresult;
	
	@FXML
	private TableView<Equipment> option;
	
	@FXML
	private TableColumn<Equipment, String> ename;
	
	@FXML
	private Button confirm;
	
	private Reservation res = new Reservation();
	private MainViewController mainvc;

	
	public ReserveViewController(){
	}
	
	@FXML
	public void initialize() {
		address.setItems(SQLSearch.getBranchList());
		type.setItems(SQLSearch.getVehicleTypeList());
		pickuphour.setItems(CommonC.Hour);
		returnhour.setItems(CommonC.Hour);
		confirm.setDisable(true); // can not confirm if transaction is not checked
		
		/* set all choicebox select first column*/
		address.getSelectionModel().selectFirst();
		type.getSelectionModel().selectFirst();
		pickupdate.setValue(LocalDate.now());
		returndate.setValue(LocalDate.now());	
		pickuphour.getSelectionModel().selectFirst();
		returnhour.getSelectionModel().selectFirst();
		option.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);
		ename.setCellValueFactory(new PropertyValueFactory<Equipment, String>("ename"));
	}
	
	@FXML
	protected void check(){
		
		int bid;
		String bids;
		String vtype;
		PreparedStatement ps;
		ResultSet rs;
		
		bids = address.getSelectionModel().getSelectedItem().toString();
		bid = Translate.SToI(bids);
		vtype = type.getSelectionModel().getSelectedItem().toString();
		
		try{
			ps = SQLConnect.getcon().prepareStatement("SELECT V.vid FROM Vehicle V JOIN Maintain M on V.vid = M.vid AND V.type = ? AND M.bid = ? AND V.status = 1");
			ps.setString(1, vtype);
			ps.setInt(2, bid);
			
			rs = ps.executeQuery();
			
			if( ! rs.next() ) {
				DBresult.setText("No vehicle is available now on that location.");
			}
			else {
				res.setvid(rs.getInt("vid"));
				res.setbid(bid);
				
				DBresult.setText("Vehicle " + res.getvid() + " is available at location " + bid + ".");
				confirm.setDisable(false); // now can confirm
				address.setDisable(true); // can not change parameters
				type.setDisable(true);
				
				if ( Translate.isCar(vtype) ) option.setItems(SQLSearch.getAdditionalEquipment(1));
				else option.setItems(SQLSearch.getAdditionalEquipment(0));
				
				option.getColumns().addAll(ename);
				option.getSelectionModel().selectFirst();
			}
		} catch (SQLException ex) {
			DBresult.setText("Database error.");
		}
		
		
	}
	
	@FXML
	protected void confirm(){
		LocalDate pdate = pickupdate.getValue();
		LocalDate rdate = returndate.getValue();
		int phour = pickuphour.getValue();
		int rhour = returnhour.getValue();
		String opt;
		
		if(pdate.isBefore(LocalDate.now()) || rdate.isBefore(LocalDate.now())) {
			DBresult.setText("Invalid time period");
			return ;
		}
		
		if( pdate.isAfter(rdate) || ( pdate.isEqual(rdate) && phour >= rhour ) ) {
			DBresult.setText("Invalid time period");
			return ;
		}
		
		Calendar pickcal = Calendar.getInstance();
		pickcal.set(Calendar.YEAR, pdate.getYear());
		pickcal.set(Calendar.MONTH, pdate.getMonthValue() - 1);
		pickcal.set(Calendar.DAY_OF_MONTH, pdate.getDayOfMonth());
		pickcal.set(Calendar.HOUR_OF_DAY, phour);
		pickcal.set(Calendar.MINUTE, 0);
		pickcal.set(Calendar.SECOND, 0);
		pickcal.set(Calendar.MILLISECOND, 0);
		
		Calendar returncal = Calendar.getInstance();
		returncal.set(Calendar.YEAR, rdate.getYear());
		returncal.set(Calendar.MONTH, rdate.getMonthValue() - 1);
		returncal.set(Calendar.DAY_OF_MONTH, rdate.getDayOfMonth());
		returncal.set(Calendar.HOUR_OF_DAY, rhour);
		returncal.set(Calendar.MINUTE, 0);
		returncal.set(Calendar.SECOND, 0);
		returncal.set(Calendar.MILLISECOND, 0);
		
		res.setstartdate(pickcal);
		res.setreturndate(returncal);

		opt = option.getSelectionModel().getSelectedItem().toString().substring(0,3);		
		res.setequip(opt);
		
		try {
			FXMLLoader loader = new FXMLLoader();
			loader.setLocation(MainController.class.getResource("view/InformationView.fxml"));
			AnchorPane info = (AnchorPane) loader.load();
		
			InformationViewController con = loader.getController();
			con.setReservation(this.res);
			mainvc.setRight(info);
		} catch (IOException e) {
			e.printStackTrace();
		}

	}
	
	public void setMainVC(MainViewController m) {
		this.mainvc = m;
	}
}
