package cs.model;

public class Equipment {
	private String ename;
	
	public Equipment () {
		this.ename = "";
	}
	
	public Equipment (String e) {
		this.ename = e;
	}
	
	public String getName () {
		return ename;
	}
	
	public void setName(String e) {
		this.ename = e;
	}
}
