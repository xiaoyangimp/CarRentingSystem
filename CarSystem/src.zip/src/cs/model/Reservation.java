package cs.model;

import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

public class Reservation extends Transaction {

	private final IntegerProperty bid;
	private final IntegerProperty vid;
	private final IntegerProperty confirmnum;
	private final StringProperty cname;
	private final StringProperty cphonenum;
	
	public Reservation() {
		super();
		this.bid = new SimpleIntegerProperty (-1);
		this.vid = new SimpleIntegerProperty (-1);
		this.confirmnum = new SimpleIntegerProperty(-1);
		this.cname = new SimpleStringProperty(null);
		this.cphonenum = new SimpleStringProperty(null);
	}
	
	public int getbid() {
		return bid.get();
	}
	
	public void setbid(int t){
		this.bid.set(t);
	}
	
	public int getvid() {
		return vid.get();
	}
	
	public void setvid(int t){
		this.vid.set(t);
	}
	
	public int getconfirmnum() {
		return confirmnum.get();
	}
	
	public void setconfirmnum(int t){
		this.confirmnum.set(t);
	}
	
	public String getcname() {
		return cname.get();
	}
	
	public void setcname(String n){
		this.cname.set(n);
	}
	
	public String getcphonenum() {
		return cphonenum.get();
	}
	
	public void setcphonenum(String n){
		this.cphonenum.set(n);
	}

}
