package cs;

import java.io.IOException;

import cs.model.Employee;
import cs.view.MainViewController;
import cs.view.ToolbarController;
import cs.view.WelcomeViewController;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;



public class MainController {

	private Stage primaryStage;
	private Employee currentUser = new Employee();
	private AnchorPane mainView;
	private MainViewController mainvc;
	
	
	public MainController(){
		
	}
	
	public void showGUI(Employee t) {
		this.primaryStage = new Stage();
		this.primaryStage.setTitle("SuperRent System");
		this.currentUser = t; 
		
		showMainGUI();
	}
	
	public void showMainGUI() {
		try {
			// Load main View
			FXMLLoader loader = new FXMLLoader();
			loader.setLocation(MainController.class.getResource("view/MainView.fxml"));
			mainView = (AnchorPane) loader.load();

			mainvc = loader.getController();
			ToolbarController toolcon;
			WelcomeViewController welcomecon;
			AnchorPane toolbar, welcome;
			
			mainvc.setMain(this);
			mainvc.setParam(currentUser.getuserid(), currentUser.getposition());
			
			if(currentUser.getposition().equals("adm")){
				FXMLLoader loader2 = new FXMLLoader();
				loader2.setLocation(MainController.class.getResource("view/AdminToolbar.fxml"));
				toolbar = (AnchorPane) loader2.load();
				
				toolcon = loader2.getController();
				toolcon.setMain(this);
				mainvc.setLeft(toolbar);
			}
			else {
				toolbar = new AnchorPane();
			}
			
			FXMLLoader loader3 = new FXMLLoader();
			loader3.setLocation(MainController.class.getResource("view/WelcomeView.fxml"));
			welcome = (AnchorPane) loader3.load();
			
			welcomecon = loader3.getController();
			welcomecon.initiate();
			mainvc.setRight(welcome);
			
			Scene scene = new Scene(mainView);
			
			primaryStage.setScene(scene);
			primaryStage.show();
			
		} catch (IOException e) {
			e.printStackTrace();
		}
		
	}
	
	
	public Stage getPrimaryStage() {
		return primaryStage;
	}
	
	public AnchorPane getMainView() {
		return mainView;
	}
	
	public MainViewController getMainViewController(){
		return mainvc;
	}
	
}
