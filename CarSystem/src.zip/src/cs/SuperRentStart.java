package cs;

import java.io.IOException;

import cs.model.Employee;
import cs.view.LoginViewController;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;
import java.sql.*;


public class SuperRentStart extends Application {
	
	private Stage primaryStage;
	private Employee tempRecord = new Employee();
	
	
	public SuperRentStart(){

	}
	
	@Override
	public void start(Stage primaryStage) {
		this.primaryStage = primaryStage;
		this.primaryStage.setTitle("SuperRent Login");
		
		showLoginView();
	}
	
	public void showLoginView() {
		try {
			// Load Login View
			FXMLLoader loader = new FXMLLoader();
			loader.setLocation(SuperRentStart.class.getResource("view/LoginView.fxml"));
			GridPane loginView = (GridPane) loader.load();

			Scene scene = new Scene(loginView);
			LoginViewController control = loader.getController();
			control.setStart(this);
			
			primaryStage.setScene(scene);
			primaryStage.show();
			
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		if(SQLConnect.connect()){
			System.out.println("Connect OK!");
		} 
		else {
			System.out.println("Server error!");
		}
	}
		
	
	public void login(String uid, String pwd) {
		tempRecord.setuserid(uid);
		tempRecord.setpassword(pwd);
		PreparedStatement ps;
		ResultSet rs;

		try {
				ps = SQLConnect.getcon().prepareStatement("SELECT * FROM Employee WHERE empid = ? AND password = ?");
				ps.setString(1, uid);
				ps.setString(2, pwd);
				
				rs = ps.executeQuery();
				
				if( ! rs.next() ) {
					System.out.println("Invalid userid or password!");
				} else {
					tempRecord.setposition(rs.getString("position"));
		
					primaryStage.close();
					MainController m = new MainController();
					m.showGUI(this.tempRecord);
				}
				
				ps.close();
				
				
		} catch(SQLException ex) {
				System.out.println("Message:" + ex.getMessage());
		}

	}
	
	
	public Stage getPrimaryStage() {
		return primaryStage;
	}
	
	
	public static void main(String[] args) {
		launch(args);
	}
}
