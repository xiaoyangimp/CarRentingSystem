package cs.constant;

import cs.constant.CommonC;

public class Translate {
	
	/** function that used to get the first several integer
	 * at the beginning of a string
	 * */
	public static int SToI (String instring) {
		int temp = 0;
		int index = 0;
		
		while(instring.charAt(index) >= '0' && 
				instring.charAt(index) <= '9') {
			temp *= 10;
			temp = instring.charAt(index) - '0';
			index++;
		}
		
		return temp;
	}
	
	/**
	 * function that determine whether the vehicle type is a car
	 */
	
	public static boolean isCar(String tojudge) {
		if( CommonC.CarType.contains(tojudge) ) return true;
		else return false;
	}
}
