package cs;

import java.sql.*;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

public class SQLSearchChoiceBox {
	
	public static ObservableList<String> getBranchList() {
		ObservableList<String> temp = FXCollections.observableArrayList();
		
		int bid;
		String bcity;
		String baddr;
		StringBuffer btemp = new StringBuffer();
		Statement stmt;
		ResultSet rs;
		
		try
		{
			stmt = SQLConnect.getcon().createStatement();
			
			rs = stmt.executeQuery("SELECT * FROM Branch");
			
			while(rs.next()) {
				bid = rs.getInt("bid");
				bcity = rs.getString("city");
				baddr = rs.getString("address");
				
				btemp.append(bid);
				btemp.append(". ");
				btemp.append(bcity);
				btemp.append("-");
				btemp.append(baddr);
				
				temp.add(btemp.toString());
				btemp.delete(0, btemp.length());
			}
			
		} 	catch (SQLException ex) {
			System.out.println("Message: " + ex.getMessage());
		}
		
		return temp;
	}
	
	public static ObservableList<String> getVehicleTypeList(){
		ObservableList<String> temp = FXCollections.observableArrayList();
		
		String vtype;
		Statement stmt;
		ResultSet rs;
		
		try
		{
			stmt = SQLConnect.getcon().createStatement();
			
			rs = stmt.executeQuery("SELECT * FROM VehicleType");
			
			while(rs.next()) {
				vtype = rs.getString("type");
				
				temp.add(vtype);
			}
			
		} 	catch (SQLException ex) {
			System.out.println("Message: " + ex.getMessage());
		}
		
		return temp;
	}
	

}
